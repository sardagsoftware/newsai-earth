Ailydian AI Video Clip (3:33)
- input/song.wav → şarkı (WAV/MP3)
- input/images/  → görseller (senaryo adlarıyla)
- input/scenario.txt → süre|görsel|efekt|geçiş
Çalıştır:
  pip install -r requirements.txt
  python generate_clip.py
